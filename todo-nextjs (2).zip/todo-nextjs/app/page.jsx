"use client";
import { useEffect, useState } from "react";

const ESTADOS = ["Pendiente", "En Proceso", "Completada"];

export default function Home() {
  const [tareas, setTareas] = useState([]);
  const [titulo, setTitulo] = useState("");
  const [descripcion, setDescripcion] = useState("");
  const [siguienteId, setSiguienteId] = useState(1);
  const [filtro, setFiltro] = useState("Todas");
  const [cargado, setCargado] = useState(false);

  useEffect(() => {
    try {
      const guardadas = localStorage.getItem("todo-nextjs-tareas");
      if (guardadas) {
        const datos = JSON.parse(guardadas);
        if (Array.isArray(datos)) {
          setTareas(datos);
          setSiguienteId(datos.reduce((max, t) => Math.max(max, Number(t.id) || 0), 0) + 1);
        }
      }
    } catch { /* Si el almacenamiento no es válido, se inicia una lista vacía. */ }
    setCargado(true);
  }, []);

  useEffect(() => {
    if (cargado) {
      try { localStorage.setItem("todo-nextjs-tareas", JSON.stringify(tareas)); }
      catch { /* La app sigue funcionando si el almacenamiento está deshabilitado. */ }
    }
  }, [tareas, cargado]);

  function agregarTarea(e) {
    e.preventDefault();
    const nombre = titulo.trim();
    if (!nombre) return;
    setTareas(actuales => [...actuales, {
      id: siguienteId, titulo: nombre,
      descripcion: descripcion.trim() || "Sin descripción",
      estado: "Pendiente"
    }]);
    setSiguienteId(id => id + 1);
    setTitulo("");
    setDescripcion("");
  }

  function cambiarEstado(id, estado) {
    setTareas(actuales => actuales.map(t => t.id === id ? { ...t, estado } : t));
  }
  function eliminarTarea(id) {
    setTareas(actuales => actuales.filter(t => t.id !== id));
  }

  const visibles = filtro === "Todas" ? tareas : tareas.filter(t => t.estado === filtro);
  const completadas = tareas.filter(t => t.estado === "Completada").length;

  return <main className="pagina">
    <section className="panel">
      <header className="encabezado">
        <div><p className="sobrelinea">ORGANIZA TU DÍA</p><h1>Gestor de tareas</h1>
          <p className="introduccion">Agrega actividades, actualiza su estado y lleva el control de tu progreso.</p>
        </div>
        <div className="resumen"><strong>{tareas.length}</strong><span>tareas</span><small>{completadas} completadas</small></div>
      </header>

      <section className="formulario-seccion">
        <h2>Agregar una tarea</h2>
        <form className="formulario" onSubmit={agregarTarea}>
          <label>Título <span className="requerido">*</span>
            <input value={titulo} onChange={e => setTitulo(e.target.value)} placeholder="Ej. Terminar el proyecto" maxLength={100} required />
          </label>
          <label>Descripción
            <textarea value={descripcion} onChange={e => setDescripcion(e.target.value)} placeholder="Escribe algunos detalles..." rows={3} maxLength={500} />
          </label>
          <button className="boton-principal" type="submit">+ Agregar tarea</button>
        </form>
      </section>

      <section className="lista-seccion">
        <div className="lista-cabecera"><div><h2>Lista de tareas</h2><p>Administra el estado de cada actividad.</p></div>
          <label className="filtro">Filtrar por estado
            <select value={filtro} onChange={e => setFiltro(e.target.value)}>
              <option>Todas</option>{ESTADOS.map(e => <option key={e}>{e}</option>)}
            </select>
          </label>
        </div>
        <div className="tabla-contenedor"><table>
          <thead><tr><th>ID</th><th>Título</th><th>Descripción</th><th>Estado</th><th>Acciones</th></tr></thead>
          <tbody>{visibles.length === 0 ? <tr><td className="vacio" colSpan="5">
            {tareas.length === 0 ? "Todavía no hay tareas. Agrega la primera con el formulario." : "No hay tareas para este filtro."}
          </td></tr> : visibles.map(t => <tr key={t.id}>
            <td className="id-celda">#{t.id}</td><td className="titulo-celda">{t.titulo}</td><td className="descripcion-celda">{t.descripcion}</td>
            <td><span className={"estado estado-" + t.estado.toLowerCase().replace(" ", "-")}>{t.estado}</span></td>
            <td><div className="acciones">
              <label className="sr-only" htmlFor={"estado-" + t.id}>Cambiar estado de {t.titulo}</label>
              <select id={"estado-" + t.id} value={t.estado} onChange={e => cambiarEstado(t.id, e.target.value)}>
                {ESTADOS.map(e => <option key={e}>{e}</option>)}
              </select>
              <button className="boton-eliminar" type="button" onClick={() => eliminarTarea(t.id)}>Eliminar</button>
            </div></td>
          </tr>)}</tbody>
        </table></div>
        <p className="nota">Los cambios se guardan en este navegador mediante localStorage.</p>
      </section>
    </section>
    <footer>Aplicación ToDo · React Hooks · Next.js</footer>
  </main>;
}