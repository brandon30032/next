import "./globals.css";
export const metadata = { title: "Gestor de tareas", description: "Aplicación ToDo en Next.js" };
export default function RootLayout({ children }) {
  return <html lang="es"><body>{children}</body></html>;
}