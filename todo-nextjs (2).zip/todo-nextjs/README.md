# Gestor de tareas — Next.js

Aplicación ToDo para agregar, listar, cambiar el estado y eliminar tareas.

## Requisitos cubiertos
- Hooks `useState` y `useEffect`.
- Formulario para agregar tareas.
- Tabla con ID autogenerado, título, descripción, estado y acciones.
- Estados: Pendiente, En Proceso y Completada.
- Cambiar estado y eliminar tareas.
- Filtro por estado, diseño adaptable y guardado local con `localStorage`.

## Cómo ejecutar
1. Descomprime el ZIP y abre la carpeta `todo-nextjs` en Visual Studio Code.
2. Abre la terminal dentro de la carpeta.
3. Ejecuta `npm install`.
4. Ejecuta `npm run dev`.
5. Abre `http://localhost:3000`.

Necesitas Node.js instalado. `app/page.jsx` contiene la lógica, `app/layout.jsx` la estructura y `app/globals.css` los estilos. Los datos se guardan en el navegador actual, no en una base de datos.
